package building.indices;

public class Main {
    public static void main(String[] args) {

        BuildIndices.readFiles("input", "output", 100);
        BuildIndices.readFilesWithThreads("input", "output", 100);

    }
}