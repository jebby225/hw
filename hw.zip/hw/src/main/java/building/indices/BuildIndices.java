package building.indices;
import java.io.*;
import java.util.*;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.TimeUnit;
import java.util.stream.Collectors;

public class BuildIndices {

    public static void readFilesWithThreads(String inputFolder, String outputFolder, int page) {
        long startTime = System.currentTimeMillis(); // Start Time

        File folder = new File(inputFolder);
        if (!folder.exists() || !folder.isDirectory()) {
            System.err.println("Folder does not exist or is not a directory.");
            return;
        }

        File[] files = folder.listFiles((dir, name) -> name.toLowerCase().endsWith(".txt"));
        ExecutorService executor = Executors.newFixedThreadPool(files.length);

        for (File file : folder.listFiles((dir, name) -> name.toLowerCase().endsWith(".txt"))) {
            executor.execute(() ->  build(file, outputFolder, page)); // Submit each file to be read by a thread
        }

        // Shutdown the executor and wait for all tasks to finish
        executor.shutdown();
        try {
            if (executor.awaitTermination(5, TimeUnit.MINUTES)) { // Wait for all threads to finish
                System.out.println("Time: " + (System.currentTimeMillis() - startTime) + " ms");
            } else {
                System.err.println("Timeout reached before all files were processed.");
            }
        } catch (InterruptedException e) {
            System.err.println("Thread interrupted: " + e.getMessage());
        }
    }

    public static void readFiles(String inputFolder, String outputFolder, int page) {
        long startTime = System.currentTimeMillis(); // Start Time

        File folder = new File(inputFolder);
        // Check if folder exists and is a directory
        if (!folder.exists() || !folder.isDirectory()) {
            System.err.println("Folder does not exist or is not a directory.");
            return;
        }

        for (File file : folder.listFiles((dir, name) -> name.toLowerCase().endsWith(".txt"))) {
            build(file, outputFolder, page);
        }
        System.out.println("Time: " + (System.currentTimeMillis()-startTime) + " ms");
    }

    private static void build(File inputFile, String outputFolder, int page)  {

        LinkedHashMap<String, Set<Integer>> idxMap = new LinkedHashMap<>();

        String token;
        String inputFileName = inputFile.getName().substring(0, inputFile.getName().lastIndexOf("."));
        int cnt = 0;
        int currPage = 1;

        try (BufferedReader reader = new BufferedReader(new FileReader(inputFile))) {
            String line;
            while ((line = reader.readLine()) != null) {
                StringTokenizer tokenizer = new StringTokenizer(line, " "); // Split by spaces, commas, dots, exclamation marks

                // Tokenize the string and print each token
                while (tokenizer.hasMoreTokens()) {
                    token = tokenizer.nextToken().toLowerCase();
                    if(cnt + token.length() > page) {
                        cnt = token.length();
                        currPage++;
                    }
                    else {
                        cnt += token.length();
                    }

                    // idxHM.putIfAbsent(token, idxHM.getOrDefault(token, new HashSet<>()).add(currPage));
                    if(idxMap.containsKey(token)) {
                        idxMap.get(token).add(currPage);
                    } else {
                        idxMap.put(token, new HashSet<Integer>());
                        idxMap.get(token).add(currPage);
                    }
                }
            }
        } catch (IOException e) {
            System.err.println("Error reading file: " + e.getMessage());
        } catch (Exception e) {
            System.err.println("Error reading file: " + e.getMessage());
        }

        try (BufferedWriter writer = new BufferedWriter(new FileWriter(outputFolder + "/" + inputFileName +"_output.txt"))) {
            for(Map.Entry<String, Set<Integer>> entry : idxMap.entrySet()) {
                writer.write(entry.getKey() + " " + String.join(", ", entry.getValue().stream().map(String::valueOf).collect(Collectors.joining(", "))));
                writer.newLine();
            }
            System.out.println("Sorted HashMap written to file successfully.");
        } catch (IOException e) {
            System.err.println("Error writing to file: " + e.getMessage());
        }
    }
}


